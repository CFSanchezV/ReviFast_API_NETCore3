﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Revifast.Api.Models.Distrito
{
    public class DistritoViewModel
    {
        public int DistritoId { get; set; }
        public string Nombre { get; set; }
    }
}
