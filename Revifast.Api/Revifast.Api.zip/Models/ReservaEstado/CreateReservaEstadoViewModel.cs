﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Revifast.Api.Models.ReservaEstado
{
    public class CreateReservaEstadoViewModel
    {
        // ESTADO
        public string Estado { get; set; }
    }
}
