﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Revifast.Api.Models.Departamento
{
    public class DepartamentoViewModel
    {
        public int DepartamentoId { get; set; }
        public string Nombre { get; set; }
    }
}
