﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Revifast.Api.Models.Marca
{
    public class MarcaViewModel
    {
        public int MarcaId { get; set; }
        // NOMBRE
        public string Nombre { get; set; }
    }
}
